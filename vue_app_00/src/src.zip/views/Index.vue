<template>
    <section style="margn-top:0px;">
        <myheader></myheader>
        <!-- 轮播图 -->
        <carousel></carousel>
        <myfooter></myfooter>
    </section>
</template>
<script>
import carousel from "../components/Index/Carousel.vue"
import MyHeader from "../components/web1908/xz/MyHeader.vue"
import MyFooter from "../components/web1908/xz/MyFooter.vue"
export default {
    components:{ carousel,
        "myheader":MyHeader,
        "myfooter":MyFooter,
    },
}
</script>
<style scoped>
    
</style>