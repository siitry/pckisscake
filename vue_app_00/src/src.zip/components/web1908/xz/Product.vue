<template>
    <div class="product_app">
        <!-- <h3>Product.vue商品列表</h3> -->
        <!-- 一个商品信息 -->
        <div class="goods-item" v-for="(item,i) of list" :key="i">
            <!-- 商品图片 -->
            <img :src="'http://127.0.0.1:4000/'+item.pic">
            <!-- 商品名称 -->
            <h4>{{item.lname}}</h4>
            <h5 class="price">{{item.price.toFixed(2)}}</h5>
            <mt-button @click="addcart" :data-lid="item.lid" :data-lname="item.lname" :data-price="item.price" style="background:#0aa1ed;color:#fff;">加入购物车</mt-button>
        </div>
        <!-- 查询购物车 -->
        <mt-button size="large" @click="jumpCart">查看购物车</mt-button>
        <!-- 加载更多 -->
        <mt-button size="large" @click="loadMore">加载更多</mt-button>
        <!-- {{list}} -->
    </div>
</template>
<script>
export default {
    created(){//组件创建成功后加载
        this.loadMore();//加载数据
    },
    data(){//保存共享数据
        return {
            list:[],//服务器返回的结果
            pno:0,//当前显示的页码
        }
    },
    methods:{//添加函数
        jumpCart(){
            //功能:跳转购物车组件
            this.$router.push("/Cart")
        },
        addcart(event){ //event:事件对象,.target触发事件对象(按钮)
            //功能:添加至购物车
            console.log(1);
            //1.在参数中添加属性event
            //2.获取三个参数
            var lid = event.target.dataset.lid;//.dataset专用于保存自定义属性值对象
            var price = event.target.dataset.price;
            var lname = event.target.dataset.lname;
            console.log(2);
            console.log(lid+":"+price+":"+lname);
            //3.创建变量url
            var url = "addcart";
            //4.创建变量obj
            var obj = {lid,lname,price}
            //5.发送ajax请求
            this.axios.get(url,{params:obj}).then(res=>{
                console.log(3);
                console.log(res);
                if(res.data.code==-2){
                    this.$toast("请登录!");
                    this.$router.push("/Login");
                }else{
                    this.$toast("添加成功")
                }
            })
            //6.获取服务器返回的数据
        },
        loadMore(){
            //功能:加载下一个数据
            this.pno++;
            console.log(1);
            //1.创建变量url
            var url = "product";
            //2.创建变量obj
            var obj = {pno:this.pno};
            //3.发送ajax请求
            this.axios.get(url,{params:obj})
            .then(res=>{
                //console.log(2);
                //console.log(res.data.data)
                //4.获取服务器返回结果
                //5.在data添加属性list
                //  保存返回数据
                //this.list=res.data.data;//第一个data是ajax返回,第二个data是上面的data
                var rows=this.list.concat(res.data.data);
                this.list = rows;
                //6.在模板创建循环显示数据
            })
        }
    }
}
</script>
<style scoped>
    /*1.最外层父元素*/
    .product_app{
        /*弹性布局 子元素两端对齐 */
        display:flex;
        flex-wrap: wrap;
        justify-content: space-between;
        padding:4px;/*内边距 */
    }
    /*2.一个商品*/
    .goods-item{
        width:48%;/*一半 */
        border:1px solid #ccc;
        border-radius: 5px; /*圆角 */
        margin:2px 0;/*外边距 */
        padding:2px;
        display: flex;/*弹性布局 */
        flex-direction: column;/*按列 */
        min-height:257px;
    }
    /*3.一个商品的图片*/
    .goods-item img{
        width:100%;
    }
</style>