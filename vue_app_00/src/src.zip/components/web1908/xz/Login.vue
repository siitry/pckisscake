<template>
    <div>
        <!-- <h3>Login.vue</h3> -->
        <mt-field label="用户名" v-model="uname" placeholder="请输入用户名"></mt-field>
        <mt-field label="密码" v-model="upwd" placeholder="请输入密码"></mt-field>
        <mt-button @click="login" size="large">登录</mt-button>
    </div>
</template>
<script>
export default {
    data(){
        return {
            uname:"tom",//双向绑定
            upwd:"123",//用户名密码
        }
    },
    methods:{
        login(){
            console.log(1);
            //功能:完成用户登录
            //1.创建正则表达式3~12
            var reg = /^[a-zA-Z0-9]{3,12}$/;
            //2.获取用户名和密码
            var u = this.uname;
            var p = this.upwd;
            console.log(2);
            console.log(u + ":" + p)
            //3.验证用户名不正确显示出错信息
            if(!reg.test(u)){
                this.$messagebox("消息","用户名格式不正确");
                //4.返回
                return;
            }
            //5.验证密码不正确显示错误信息
            if(!reg.test(p)){
                this.$messagebox("消息","密码格式不正确");
                //6.返回
                return;
            }
            console.log(3);
            console.log(u + ":" +p);
            //7.发送ajax请求
            var url = "login";
            var obj = {uname:u,upwd:p};
            console.log(4);
            console.log(obj);
            this.axios.get(url,{params:obj})
            .then(res=>{//成功的回调函数
                console.log(5);
                console.log(res);
            //8.获取服务器返回结果
                if(res.data.code==-1){
                    console.log(6);
                    //9.出错显示出错信息
                    this.$messagebox("消息","用户名或密码错误");
                }else{
                    console.log(7);
                    //10.跳转/Product
                    this.$router.push("/Product");
                }
            })
        }
    }
}
</script>
<style scoped>

</style>