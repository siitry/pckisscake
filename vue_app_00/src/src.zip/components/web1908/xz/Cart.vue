<template>
    <section style="margn-top:0px;">
        <myheader></myheader>
        <div class="cart">
            <div class="cartbox">
                <div class="cartimg">
                    <img src="../../../img/cart/cart_headimg.png">
                </div>
                <div class="cartinfo">
                    您的购物车是空的，您可以
                    <a href="">选购商品>></a>
                    <a class="a2" href="">查看订单>></a>
                </div>
            </div>
        </div>
        <myfooter></myfooter>
     </section>
</template>
<script>
import MyHeader from "./MyHeader"
import MyFooter from "./MyFooter"
export default {
    components:{
        "myheader":MyHeader,
        "myfooter":MyFooter
    }
}
</script>
<style scoped>
    .cart{
        width:100%;height:258px;
        border-top:1px solid #D8D0D0;
        margin-bottom:120px;
    }
    .cartbox{
        width:1200px;height:358px;
        margin:0 auto;
        position: relative;
    }
    .cartimg{
        position:absolute;
        left:41%;
        background:#fff;
        margin-top:20px;
    }
    .cartinfo{
        display: block;
        width:1200px;height:100px;
        position:absolute;
        top:160px;
        background:#F1F1F1;
        text-align:center;
        line-height: 100px;
        font-size:18px;
        color:#464646;
    }
    .cartinfo a{
        text-decoration:none;
        font-size:14px;
        color:#464646;
        margin-left:10px;
    }
    .cartinfo .a2{
        margin-left:30px;
    }
</style>