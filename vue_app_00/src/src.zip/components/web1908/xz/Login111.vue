<template>
    <div>
        <div class="loginhead">
            <img src="../../../img/f1/logo.png" alt="">
        </div>
        <div class="h1">
            <div class="logun-box">
                <div class="logintitle">
                    <span class="s1">密码登录</span>
                    <a href=""><span class="s2">验证码登录</span></a>
                </div>
                <input type="text" placeholder="手机号">
                <input type="text" placeholder="密码">
                <button>立即登录</button>
                <p>提示还不是会员？ 通过短信登录，<a href="">自动登录</a>为会员~</p>
            </div>
        </div>
        <a href=""><img class="img1" src="../../../img/online.png" alt=""></a>
    </div>
</template>
<script>
export default {
    
}
</script>
<style scoped>
    *{padding: 0;margin: 0;}
    .loginhead{
        text-align: center;
        margin:45px 0;
        border-bottom: 1px solid #e4e4e4;
    }
    .loginhead img{
        width: 100px;
        height: 60px;
        margin-bottom: 23px;
    }
    .logun-box{
    width: 330px;
    height: 270px;
    margin: 97px 795px;
    border-bottom: 1px solid #e4e4e4;
    }
    .logintitle{
        height: 40px;
        width: 332px;
        line-height: 40px;
        font-size: 14px;
        background: #522725;
        margin-bottom: 20px; 
    }
    .s1{
        display: inline-block;
        cursor: pointer;
        width: 50%;
        height: 100%;
        color: #fff;
        text-align: center;
        background: #965653;
    }
    .s2{
        display: inline-block;
        color: #fff;
        margin-left: 30px;
    }
    input{
        border: 1px solid #ebebeb;
        height: 41px;
        line-height: 41px;
        width: 328px;
        margin-bottom: 20px;
        outline: none;
        text-indent: 15px;
        color: rgba(0, 0, 0, 0.747);
    }
    button{
        height: 41px;
        width: 328px;
        background: #522725;
        color: linen;
        border: none;
        margin: 15px 0 20px;
        font: 16px "微软雅黑";
    }
    .h1{
        height: 380px;
        border-bottom: 1px solid gray;
    }
    p{
        color: #854d4b;
        font-size: 12px;
        margin-top: 20px;
        margin-left: 21px;
    }
    .img1{
        position: absolute;
        right: 10px;
        top: 220px;
    }
</style>